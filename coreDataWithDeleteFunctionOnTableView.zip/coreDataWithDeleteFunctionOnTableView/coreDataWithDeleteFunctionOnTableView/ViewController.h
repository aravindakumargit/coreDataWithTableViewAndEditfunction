//
//  ViewController.h
//  coreDataWithDeleteFunctionOnTableView
//
//  Created by Aravindakumar on 24/10/15.
//  Copyright © 2015 Aravindakumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *versionTextField;
@property (strong,nonatomic) NSManagedObject *device;

@property (weak, nonatomic) IBOutlet UITextField *companyTextField;
- (IBAction)save:(id)sender;

@end

