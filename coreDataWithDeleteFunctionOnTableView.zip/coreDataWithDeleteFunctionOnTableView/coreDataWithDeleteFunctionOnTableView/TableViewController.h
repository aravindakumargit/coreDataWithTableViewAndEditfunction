//
//  TableViewController.h
//  coreDataWithDeleteFunctionOnTableView
//
//  Created by Aravindakumar on 24/10/15.
//  Copyright © 2015 Aravindakumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface TableViewController : UITableViewController<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,retain)NSMutableArray *devices;
@property (strong,nonatomic) NSManagedObject *device;

@end
