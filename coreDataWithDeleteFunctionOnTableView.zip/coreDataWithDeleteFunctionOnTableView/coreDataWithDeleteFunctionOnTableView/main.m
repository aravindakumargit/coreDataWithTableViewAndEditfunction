//
//  main.m
//  coreDataWithDeleteFunctionOnTableView
//
//  Created by Aravindakumar on 24/10/15.
//  Copyright © 2015 Aravindakumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
